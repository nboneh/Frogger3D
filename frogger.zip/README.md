Who: Nir Boneh, Brian Kidd

What: OpenGL Frogger 3D

W/A/S/D - to move frog
Arrow Keys - to rotate scene (feature will be removed later)

Left to be done:
Car models, turtle models, and death animations. Add game logic to winning row, lives, levels, and timer.
Hopefully add shadows and sounds.