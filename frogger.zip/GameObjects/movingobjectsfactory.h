#include "../Frogger3D.h"

#ifndef MOVINGOBJECT_H
#include "movingobject.h"
#endif

#include <string>

MovingObject* getMovingObject(std::string type);